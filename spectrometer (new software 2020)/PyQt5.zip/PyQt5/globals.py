dev_handle = 0
pixels = 4096
spectraldata = [0.0] * 4096